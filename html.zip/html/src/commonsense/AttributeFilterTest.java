package commonsense;

public class AttributeFilterTest {

	public static void main(String[] args) {
		AttributeFilter test = new AttributeFilter("attributes.json");

	}

}
